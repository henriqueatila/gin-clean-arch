# Clean Architecture 5 Golden Rules Audit

## Scope

- Files: 9 (SKILL.md + 8 references)
- Total LOC: 2698
- Focus: All code examples in recommended/correct patterns
- BAD/anti-pattern examples excluded from violation checks

## Overall Assessment

The skill documentation is **well-structured and largely compliant** with the 5 Golden Rules. Code examples consistently isolate Gin to delivery, keep usecases framework-free, follow the dependency rule, separate DTOs from domain, and wire DI in `main.go`. One actionable issue found: `project-scaffolding.md` domain errors import `net/http`, which pulls an HTTP concept into the innermost layer.

---

## Critical Issues

None.

## High Priority

### 1. Domain `errors.go` imports `net/http` in `project-scaffolding.md`

**File:** `/home/henrique/gin-clean-arch/skills/gin-clean-arch/references/project-scaffolding.md`
**Lines:** 61-75

```go
import "net/http"  // <-- Rule 1 concern: HTTP concept in domain

var (
    ErrNotFound   = &AppError{Code: http.StatusNotFound, ...}
    ErrConflict   = &AppError{Code: http.StatusConflict, ...}
    ErrValidation = &AppError{Code: http.StatusUnprocessableEntity, ...}
    ErrForbidden  = &AppError{Code: http.StatusForbidden, ...}
)
```

**Rules violated:** Rule 1 (Gin/HTTP is a detail -- isolate it), Rule 3 (Dependency Rule -- domain must not depend on outer concepts).

**Why it matters:** Domain states "stdlib only" for imports, and while `net/http` is technically stdlib, using `http.StatusNotFound` etc. embeds HTTP semantics into the innermost layer. This contradicts the skill's own rule: "Entities and UseCases MUST NOT import Gin or know they are building a web API." Using `net/http` constants means the domain knows it is serving HTTP.

**Fix:** Use raw integer literals (as done correctly in `SKILL.md` line 445-448 and `error-handling.md` line 49-54):

```go
package domain

// No net/http import needed

var (
    ErrNotFound   = &AppError{Code: 404, Message: "not found"}
    ErrConflict   = &AppError{Code: 409, Message: "already exists"}
    ErrValidation = &AppError{Code: 422, Message: "validation failed"}
    ErrForbidden  = &AppError{Code: 403, Message: "forbidden"}
)
```

**Note:** SKILL.md (line 445-448) and error-handling.md (line 49-54) both do this correctly with raw ints. Only project-scaffolding.md diverges.

---

## Medium Priority

### 2. `AppError.Code` stores HTTP status codes in domain layer

**Files:** SKILL.md (lines 437-449), error-handling.md (lines 28-55), project-scaffolding.md (lines 63-75)

This is a **design tension** present throughout the skill, not a bug. The `Code int` field on `AppError` in domain stores values like 404, 409, 422 -- these are HTTP status codes. The delivery layer then does `c.JSON(appErr.Code, ...)`. This means the domain implicitly knows about HTTP status codes even when using raw ints.

A stricter interpretation of Rule 1 would use a domain-specific enum (e.g., `ErrorKind` with values like `KindNotFound`, `KindConflict`) and map to HTTP codes in delivery. However, the current approach is pragmatic and widely used in Go projects. The skill documents explicitly state the `Code` is "intended HTTP status" (error-handling.md line 29).

**Recommendation:** Acknowledge this as a deliberate pragmatic trade-off in the skill text, or add a brief note explaining why raw int codes in domain are acceptable despite the conceptual coupling.

### 3. `json` tags on domain `AppError` struct

**Files:** SKILL.md (lines 438-439), project-scaffolding.md (lines 64-65)

```go
type AppError struct {
    Code    int    `json:"-"`
    Message string `json:"error"`
}
```

The layer-separation.md (line 57) states: "No JSON tags. No database annotations" for domain entities. `AppError` has `json:"-"` and `json:"error"` tags. While `AppError` is an error type (not an entity), these tags serve JSON serialization for HTTP responses -- a delivery concern.

**Mitigation:** error-handling.md (lines 38-44) takes the cleaner approach with a custom `MarshalJSON()` method on `AppError` and keeps the struct fields tag-free internally. The two approaches are inconsistent across files.

**Recommendation:** Standardize on one approach. The `MarshalJSON` approach in error-handling.md is cleaner for domain purity. Alternatively, move the JSON-tagged version to a delivery-layer response type.

---

## Low Priority

### 4. `fmt.Fprintf(os.Stderr, ...)` in test bootstrap (testing-by-layer.md)

**File:** `/home/henrique/gin-clean-arch/skills/gin-clean-arch/references/testing-by-layer.md`
**Lines:** 178, 182, 185

Convention says use `log/slog`, not `fmt.Println` or `log.Println`. However, `fmt.Fprintf(os.Stderr, ...)` in `TestMain` is standard Go practice because `slog` is typically not yet configured and `testing.T` is unavailable in `TestMain`. This is acceptable.

### 5. `//nolint:errcheck` on container termination (testing-by-layer.md)

**File:** `/home/henrique/gin-clean-arch/skills/gin-clean-arch/references/testing-by-layer.md`
**Line:** 179

```go
defer pgc.Terminate(ctx) //nolint:errcheck
```

Convention says "no `_` for errors." This technically discards an error, but it is in a `TestMain` cleanup path where the process exits immediately after. The `//nolint` comment is at least explicit. Acceptable for test bootstrap.

### 6. `newRouter` function referenced but not defined (dependency-injection-alternatives.md)

**File:** `/home/henrique/gin-clean-arch/skills/gin-clean-arch/references/dependency-injection-alternatives.md`
**Line:** 130

```go
r := newRouter(handler)
```

`newRouter` is called but never defined in the Fx example. Not a rule violation, just a completeness gap in the code example.

---

## Positive Observations

1. **Consistent `ShouldBind*` usage** -- every binding call uses `ShouldBindJSON`, never `BindJSON`. Verified across all 9 files.
2. **Consistent `gin.New()` usage** -- all recommended code uses `gin.New()`. `gin.Default()` only appears in warning text (error-handling.md line 286).
3. **No `fmt.Println` or `log.Println`** -- all recommended code uses `log/slog` for logging. These only appear in "never do this" guidance text.
4. **`Product` entity throughout** -- no `User` entity found anywhere. All examples use `Product` consistently.
5. **`context.Context` threaded through all layers** -- every repository, usecase, and handler method accepts `ctx context.Context` as first parameter.
6. **All errors handled** -- no unhandled `_` for error returns in recommended code. Only in BAD examples and test cleanup.
7. **Constructor returns interface** -- `NewProductRepository` returns `domain.ProductRepository`, `NewProductUsecase` returns `domain.ProductUsecase`, consistently across all files.
8. **Clean DI wiring** -- all files wire dependencies in `main.go`. No `init()` functions, no globals in recommended code.
9. **Dependency Rule respected** -- usecases never import repository package, repository never imports delivery, domain imports only stdlib + uuid.
10. **File size limits met** -- SKILL.md is exactly 500 lines (at limit). All references are at or under 300 lines.

---

## Summary Table

| File | Lines | Rule Violations | Convention Violations | `gin.Default()` | `Bind*` (no Should) | `fmt/log.Println` |
|------|------:|:-:|:-:|:-:|:-:|:-:|
| SKILL.md | 500 | None | json tags on AppError (L438-439) | No | No | No |
| layer-separation.md | 294 | None | None | No | No | No |
| layer-separation-antipatterns.md | 191 | None (BAD examples intentional) | None | No | No | No |
| dependency-injection.md | 298 | None | None | No | No | No |
| dependency-injection-alternatives.md | 229 | None (BAD examples intentional) | None | No | No | No |
| repository-pattern.md | 298 | None | None | No | No | No |
| error-handling.md | 295 | None | None | No | No | No |
| testing-by-layer.md | 300 | None | fmt.Fprintf in TestMain (L178,182,185) | No | No | No |
| **project-scaffolding.md** | **293** | **`net/http` import in domain errors (L61-75)** | json tags on AppError (L64-65) | No | No | No |

### Verdict

**8 of 9 files are fully compliant.** One file (`project-scaffolding.md`) has a high-priority issue: the domain `errors.go` example imports `net/http` and uses `http.StatusNotFound` etc., contradicting the skill's own rules. The fix is trivial -- replace with raw integer literals to match SKILL.md and error-handling.md.

### Unresolved Questions

1. Should the skill explicitly document the `AppError.Code` design trade-off (HTTP codes in domain) as intentional pragmatism, or should it promote a stricter `ErrorKind` enum approach?
2. Should `json` tags on `AppError` be standardized to one approach (struct tags vs. custom `MarshalJSON`) across all files?
